Cambios
-------

* Usar case y where en `foldA23`
* Agregar comentario sobre composición de concats en `internos` y `hojas`
* Sacar argumentos innecesarios en mapA23
* Refactorizar `truncar` para hacerlo mas entendible
* Cambiar la comparación con [] por un `null` en `obtener`
* Mejorar el `testEj7`, checkeando los valores de las hojas en vez
    de sólamente la longitud. Notar que `dicc1` usa `definir`

Dudas
-----

* La corrección dice que los tests no compilan,
    pero no pude reproducir el error (ghc 8.2.1)

